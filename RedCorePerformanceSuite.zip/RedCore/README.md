# RedCore Performance Suite — Android Studio Project

## What this is
A real, compiling MVVM + Hilt + Room + Navigation Component Android project
covering the **core, non-root slice** of the RedCore Performance Suite spec:

- Dashboard (live RAM / storage / battery / network / performance score — real values via ActivityManager, BatteryManager, StatFs, ConnectivityManager)
- Device Info (real Build.* fields)
- App Manager (real installed-app list via PackageManager, search, system-app filter)
- Benchmark Center (real, timed CPU/memory/storage micro-benchmarks — genuine on-device measurements, not simulated scores — with history stored in Room)
- Logs (Room-backed activity log viewer, clearable)
- Settings (dark theme + root-confirmation persisted toggles)
- About
- DeviceTierClassifier (low-end / mid-range / flagship scaling heuristic)
- RootManager (detection + explicit user-consent request only — no bypass)
- Gaming red/black Material 3 theme, splash screen, bottom nav + quick-action navigation from Dashboard

## How to open it
1. Open Android Studio (Koala/2024.1+ recommended for AGP 8.5.2 / Kotlin 1.9.24).
2. File → Open → select this project folder.
3. Let Gradle sync — it will download the wrapper automatically since
   `gradle/wrapper/gradle-wrapper.properties` points at Gradle 8.7. If Android
   Studio asks to regenerate the wrapper jar, accept — the jar binary itself
   isn't included here since it's a binary file.
4. Run on a device or emulator (min SDK 26 / Android 8.0).

## What's NOT built yet (from the original 8-part spec)
These are each substantial modules and were intentionally left out of this
pass rather than stubbed with fake data:
- Game Center (game detection, profiles, FPS targeting)
- Smart Cleaner (cache/duplicate/large-file scanning)
- Logs UI wiring to actually record events from other modules (DAO + screen exist; nothing writes to it yet except manual testing)
- Automation Center (rule engine)
- Shizuku integration
- WorkManager background jobs
- Root-gated CPU governor / kernel tuning screens

## Honest technical notes
- Android does not expose GPU usage/frequency, per-core CPU frequency, or
  touch sampling rate to normal apps. Those spec items are either omitted or
  would require root + vendor-specific kernel nodes that vary per device —
  don't expect literal numbers for those even after adding root screens.
- RootManager only requests `su` after an explicit user tap, and every
  root/Shizuku-gated feature must check `RootManager.accessState` before
  showing itself — never assume access.
