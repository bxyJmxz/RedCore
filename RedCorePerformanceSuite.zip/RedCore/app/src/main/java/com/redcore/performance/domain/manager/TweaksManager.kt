package com.redcore.performance.domain.manager

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Real, non-root system tweaks. Every action here uses an official Android API.
 * Where Android requires a special user-granted permission (DND access, write
 * system settings), this class checks first and returns a result telling the
 * caller to send the user to the right settings screen — it never assumes
 * permission it doesn't have, and never fakes success.
 */
sealed class TweakResult {
    object Success : TweakResult()
    object PermissionRequired : TweakResult()
    data class Failed(val reason: String) : TweakResult()
}

@Singleton
class TweaksManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    // ---------- Do Not Disturb ----------

    fun hasNotificationPolicyAccess(): Boolean =
        notificationManager.isNotificationPolicyAccessGranted

    fun notificationPolicyAccessIntent(): Intent =
        Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)

    fun setDoNotDisturb(enabled: Boolean): TweakResult {
        if (!hasNotificationPolicyAccess()) return TweakResult.PermissionRequired
        return try {
            notificationManager.setInterruptionFilter(
                if (enabled) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                else NotificationManager.INTERRUPTION_FILTER_ALL
            )
            TweakResult.Success
        } catch (e: SecurityException) {
            TweakResult.Failed(e.message ?: "Permission denied")
        }
    }

    fun isDoNotDisturbActive(): Boolean =
        notificationManager.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL

    // ---------- Write System Settings (brightness lock, screen timeout) ----------

    fun canWriteSystemSettings(): Boolean = Settings.System.canWrite(context)

    fun writeSettingsPermissionIntent(): Intent =
        Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))

    /** brightnessPercent 0-100. Locks brightness to manual mode at that level. */
    fun lockBrightness(brightnessPercent: Int): TweakResult {
        if (!canWriteSystemSettings()) return TweakResult.PermissionRequired
        return try {
            val value = ((brightnessPercent.coerceIn(1, 100)) * 255) / 100
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, value)
            TweakResult.Success
        } catch (e: SecurityException) {
            TweakResult.Failed(e.message ?: "Permission denied")
        }
    }

    fun restoreAutoBrightness(): TweakResult {
        if (!canWriteSystemSettings()) return TweakResult.PermissionRequired
        return try {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
            )
            TweakResult.Success
        } catch (e: SecurityException) {
            TweakResult.Failed(e.message ?: "Permission denied")
        }
    }

    /** Extends screen-off timeout while gaming. Pass the original value to restoreScreenTimeout later. */
    fun setScreenTimeout(milliseconds: Int): TweakResult {
        if (!canWriteSystemSettings()) return TweakResult.PermissionRequired
        return try {
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, milliseconds)
            TweakResult.Success
        } catch (e: SecurityException) {
            TweakResult.Failed(e.message ?: "Permission denied")
        }
    }

    fun currentScreenTimeoutMs(): Int = try {
        Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT)
    } catch (e: Settings.SettingNotFoundException) {
        30000
    }

    // ---------- Battery optimization exemption ----------

    fun isIgnoringBatteryOptimizations(): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    fun requestIgnoreBatteryOptimizationsIntent(): Intent =
        Intent(
            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
            Uri.parse("package:${context.packageName}")
        )

    // ---------- Developer Options shortcut ----------

    fun developerOptionsIntent(): Intent =
        Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)

    fun isDeveloperOptionsEnabled(): Boolean = try {
        Settings.Global.getInt(context.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED) == 1
    } catch (e: Settings.SettingNotFoundException) {
        false
    }

    // ---------- App cache clearing (real, own app only — Android doesn't allow more without root) ----------

    fun clearAppCache(): Long {
        val before = folderSize(context.cacheDir)
        context.cacheDir.deleteRecursively()
        context.cacheDir.mkdirs()
        return before
    }

    private fun folderSize(dir: java.io.File): Long {
        if (!dir.exists()) return 0
        var size = 0L
        dir.listFiles()?.forEach { file ->
            size += if (file.isDirectory) folderSize(file) else file.length()
        }
        return size
    }
}
