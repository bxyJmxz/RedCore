package com.redcore.performance.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.redcore.performance.data.dao.BenchmarkDao
import com.redcore.performance.data.dao.GameDao
import com.redcore.performance.data.dao.LogDao
import com.redcore.performance.data.entities.BenchmarkResult
import com.redcore.performance.data.entities.GameEntity
import com.redcore.performance.data.entities.LogEntry

@Database(
    entities = [LogEntry::class, BenchmarkResult::class, GameEntity::class],
    version = 2,
    exportSchema = false
)
abstract class RedCoreDatabase : RoomDatabase() {
    abstract fun logDao(): LogDao
    abstract fun benchmarkDao(): BenchmarkDao
    abstract fun gameDao(): GameDao

    companion object {
        const val DATABASE_NAME = "redcore.db"
    }
}
