package com.redcore.performance.ui.benchmark

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.redcore.performance.data.entities.BenchmarkResult
import com.redcore.performance.databinding.ItemBenchmarkResultBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BenchmarkHistoryAdapter : ListAdapter<BenchmarkResult, BenchmarkHistoryAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemBenchmarkResultBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    class ViewHolder(private val binding: ItemBenchmarkResultBinding) : RecyclerView.ViewHolder(binding.root) {
        private val dateFormat = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
        fun bind(result: BenchmarkResult) {
            binding.overallScoreText.text = result.overallScore.toString()
            binding.detailText.text =
                "CPU ${result.cpuScore} · RAM ${result.ramScore} · Storage ${result.storageScore}"
            binding.dateText.text = dateFormat.format(Date(result.timestampMs))
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<BenchmarkResult>() {
            override fun areItemsTheSame(old: BenchmarkResult, new: BenchmarkResult) = old.id == new.id
            override fun areContentsTheSame(old: BenchmarkResult, new: BenchmarkResult) = old == new
        }
    }
}
