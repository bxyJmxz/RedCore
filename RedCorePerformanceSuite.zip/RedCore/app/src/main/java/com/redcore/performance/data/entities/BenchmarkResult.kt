package com.redcore.performance.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "benchmark_results")
data class BenchmarkResult(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cpuScore: Int,
    val ramScore: Int,
    val storageScore: Int,
    val overallScore: Int,
    val deviceModel: String,
    val timestampMs: Long = System.currentTimeMillis()
)
