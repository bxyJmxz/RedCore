package com.redcore.performance.ui.games

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.redcore.performance.databinding.ItemGameBinding

class GameCenterAdapter(
    private val onLaunch: (GameListItem) -> Unit,
    private val onFavoriteToggle: (GameListItem) -> Unit,
    private val onProfileClick: (GameListItem) -> Unit
) : ListAdapter<GameListItem, GameCenterAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemGameBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position), onLaunch, onFavoriteToggle, onProfileClick)
    }

    class ViewHolder(private val binding: ItemGameBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(
            item: GameListItem,
            onLaunch: (GameListItem) -> Unit,
            onFavoriteToggle: (GameListItem) -> Unit,
            onProfileClick: (GameListItem) -> Unit
        ) {
            binding.gameIcon.setImageDrawable(item.game.icon)
            binding.gameName.text = item.game.appName
            binding.profileText.text = item.profile
            binding.favoriteButton.text = if (item.isFavorite) "★" else "☆"

            binding.root.setOnClickListener { onLaunch(item) }
            binding.favoriteButton.setOnClickListener { onFavoriteToggle(item) }
            binding.profileText.setOnClickListener { onProfileClick(item) }
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<GameListItem>() {
            override fun areItemsTheSame(old: GameListItem, new: GameListItem) =
                old.game.packageName == new.game.packageName
            override fun areContentsTheSame(old: GameListItem, new: GameListItem) =
                old == new
        }
    }
}
