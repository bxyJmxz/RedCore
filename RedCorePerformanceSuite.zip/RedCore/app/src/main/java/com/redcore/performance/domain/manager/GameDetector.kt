package com.redcore.performance.domain.manager

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

data class DetectedGame(
    val appName: String,
    val packageName: String,
    val versionName: String?,
    val icon: Drawable?
)

data class NamedGameStatus(val displayName: String, val packageName: String, val isInstalled: Boolean)

/**
 * Detects installed games using Android's own official app category system
 * (ApplicationInfo.CATEGORY_GAME, or the legacy isGame flag on older APIs).
 * This is real developer-declared metadata, not a guess — some sideloaded
 * or improperly tagged apps won't appear here, same limitation every
 * legitimate game-detecting app has.
 */
@Singleton
class GameDetector @Inject constructor(
    @ApplicationContext private val context: Context
) {
    // Real, publicly known package names for common titles. Regional variants
    // (e.g. PUBG Mobile has different package IDs per region) aren't all covered —
    // if a title isn't detected, that's a real "not installed under this ID" result,
    // not a bug pretending otherwise.
    private val namedGames = listOf(
        "Call of Duty Mobile" to "com.activision.callofduty.shooter",
        "Roblox" to "com.roblox.client",
        "Mobile Legends" to "com.mobile.legends",
        "Free Fire" to "com.dts.freefireth",
        "PUBG Mobile" to "com.tencent.ig",
        "Genshin Impact" to "com.miHoYo.GenshinImpact"
    )

    fun detectNamedGames(): List<NamedGameStatus> {
        val pm = context.packageManager
        return namedGames.map { (name, pkg) ->
            val installed = try {
                pm.getPackageInfo(pkg, 0)
                true
            } catch (e: PackageManager.NameNotFoundException) {
                false
            }
            NamedGameStatus(name, pkg, installed)
        }
    }

    fun detectInstalledGames(): List<DetectedGame> {
        val pm = context.packageManager
        return pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { isGame(it) }
            .mapNotNull { appInfo ->
                try {
                    val pkgInfo = pm.getPackageInfo(appInfo.packageName, 0)
                    DetectedGame(
                        appName = pm.getApplicationLabel(appInfo).toString(),
                        packageName = appInfo.packageName,
                        versionName = pkgInfo.versionName,
                        icon = try { pm.getApplicationIcon(appInfo) } catch (e: Exception) { null }
                    )
                } catch (e: Exception) {
                    null
                }
            }
            .sortedBy { it.appName.lowercase() }
    }

    @Suppress("DEPRECATION")
    private fun isGame(appInfo: ApplicationInfo): Boolean {
        return appInfo.category == ApplicationInfo.CATEGORY_GAME ||
            (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
    }
}
