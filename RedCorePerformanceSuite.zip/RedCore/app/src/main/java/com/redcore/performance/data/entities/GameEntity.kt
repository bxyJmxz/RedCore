package com.redcore.performance.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "games")
data class GameEntity(
    @PrimaryKey val packageName: String,
    val isFavorite: Boolean = false,
    val profile: String = "Balanced",
    val lastLaunchedMs: Long = 0
)
