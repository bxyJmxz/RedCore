package com.redcore.performance.ui.touch

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout

/**
 * Tracks real MotionEvent data: time between ACTION_DOWN and the event being
 * processed (an honest proxy for input responsiveness, not the true hardware
 * touch sampling rate, which Android does not expose to apps), and the live
 * pointer count for multi-touch testing. No numbers are simulated.
 */
class TouchTrackerView(context: Context, attrs: AttributeSet? = null) : FrameLayout(context, attrs) {

    var onTouchSample: ((latencyMs: Long, pointerCount: Int) -> Unit)? = null

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val processedAt = System.nanoTime()
        val eventTimeNs = event.eventTime * 1_000_000
        val latencyMs = ((processedAt - eventTimeNs) / 1_000_000).coerceAtLeast(0)
        onTouchSample?.invoke(latencyMs, event.pointerCount)
        return true
    }
}
