package com.redcore.performance

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

/**
 * Application entry point.
 * Initializes logging and any app-wide singletons via Hilt.
 */
@HiltAndroidApp
class RedCoreApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        if (BuildConfigCompat.isDebug(this)) {
            Timber.plant(Timber.DebugTree())
        }
    }
}

/**
 * Small helper so we don't hard reference the generated BuildConfig
 * before the first Gradle sync (keeps this file safe to open immediately).
 */
object BuildConfigCompat {
    fun isDebug(app: Application): Boolean {
        return (app.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
    }
}
