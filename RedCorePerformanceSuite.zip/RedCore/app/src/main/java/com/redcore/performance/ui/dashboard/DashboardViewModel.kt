package com.redcore.performance.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.redcore.performance.domain.manager.DeviceStats
import com.redcore.performance.domain.manager.DeviceStatsProvider
import com.redcore.performance.domain.manager.DeviceTierClassifier
import com.redcore.performance.domain.manager.RootManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val statsProvider: DeviceStatsProvider,
    private val tierClassifier: DeviceTierClassifier,
    private val rootManager: RootManager
) : ViewModel() {

    private val _stats = MutableStateFlow<DeviceStats?>(null)
    val stats: StateFlow<DeviceStats?> = _stats.asStateFlow()

    val isRooted: Boolean by lazy { rootManager.isDeviceRooted() }
    val refreshIntervalMs: Long by lazy { tierClassifier.suggestedRefreshIntervalMs() }
    val allowPremiumEffects: Boolean by lazy { tierClassifier.allowPremiumEffects() }

    private var pollingJob: kotlinx.coroutines.Job? = null

    /** Call from onStart / repeatOnLifecycle(STARTED) — never runs while backgrounded. */
    fun startMonitoring() {
        if (pollingJob?.isActive == true) return
        pollingJob = viewModelScope.launch {
            statsProvider.observe(refreshIntervalMs).collect { snapshot ->
                _stats.value = snapshot
            }
        }
    }

    /** Call from onStop to pause background work, per the spec's "pause when minimized" rule. */
    fun stopMonitoring() {
        pollingJob?.cancel()
        pollingJob = null
    }

    /** Simple heuristic 0-100 "performance score" from real, current metrics. */
    fun performanceScore(s: DeviceStats): Int {
        val ramScore = (100 - s.ramUsedPercent).coerceIn(0, 100)
        val storageScore = (100 - s.storageUsedPercent).coerceIn(0, 100)
        val thermalPenalty = if (s.batteryTemperatureCelsius > 40f) 15 else 0
        return ((ramScore + storageScore) / 2 - thermalPenalty).coerceIn(0, 100)
    }
}
