package com.redcore.performance.ui.games

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.redcore.performance.data.dao.GameDao
import com.redcore.performance.data.entities.GameEntity
import com.redcore.performance.domain.manager.DetectedGame
import com.redcore.performance.domain.manager.GameDetector
import com.redcore.performance.domain.manager.NamedGameStatus
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

data class GameListItem(
    val game: DetectedGame,
    val isFavorite: Boolean,
    val profile: String
)

@HiltViewModel
class GameCenterViewModel @Inject constructor(
    private val gameDetector: GameDetector,
    private val gameDao: GameDao
) : ViewModel() {

    private val _detectedGames = MutableStateFlow<List<DetectedGame>>(emptyList())
    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _namedGames = MutableStateFlow<List<NamedGameStatus>>(emptyList())
    val namedGames: StateFlow<List<NamedGameStatus>> = _namedGames.asStateFlow()

    val gameList: StateFlow<List<GameListItem>> = combine(
        _detectedGames,
        gameDao.observeAll()
    ) { detected, saved ->
        val savedByPackage = saved.associateBy { it.packageName }
        detected.map { game ->
            val entity = savedByPackage[game.packageName]
            GameListItem(
                game = game,
                isFavorite = entity?.isFavorite ?: false,
                profile = entity?.profile ?: "Balanced"
            )
        }.sortedByDescending { it.isFavorite }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun scanForGames() {
        viewModelScope.launch {
            _isLoading.value = true
            val games = withContext(Dispatchers.Default) { gameDetector.detectInstalledGames() }
            val named = withContext(Dispatchers.Default) { gameDetector.detectNamedGames() }
            _detectedGames.value = games
            _namedGames.value = named
            _isLoading.value = false
        }
    }

    fun toggleFavorite(packageName: String, currentlyFavorite: Boolean) {
        viewModelScope.launch {
            val existing = gameDao.getByPackage(packageName)
            gameDao.upsert(
                existing?.copy(isFavorite = !currentlyFavorite)
                    ?: GameEntity(packageName = packageName, isFavorite = !currentlyFavorite)
            )
        }
    }

    fun setProfile(packageName: String, profile: String) {
        viewModelScope.launch {
            val existing = gameDao.getByPackage(packageName)
            gameDao.upsert(
                existing?.copy(profile = profile)
                    ?: GameEntity(packageName = packageName, profile = profile)
            )
        }
    }
}
