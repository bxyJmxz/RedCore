package com.redcore.performance.domain.shizuku

import android.content.Context
import android.content.pm.PackageManager
import dagger.hilt.android.qualifiers.ApplicationContext
import rikka.shizuku.Shizuku
import javax.inject.Inject
import javax.inject.Singleton

enum class ShizukuState {
    NOT_INSTALLED,
    NOT_RUNNING,
    RUNNING_NOT_AUTHORIZED,
    AUTHORIZED
}

/**
 * Wraps the official Shizuku SDK. All state comes from Shizuku.pingBinder() /
 * checkSelfPermission() / requestPermission() — the same calls any legitimate
 * Shizuku-integrated app uses. This class never bypasses Shizuku's own
 * permission model; it only reflects and requests through it.
 */
@Singleton
class ShizukuManager @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private var permissionListener: Shizuku.OnRequestPermissionResultListener? = null

    companion object {
        private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    }

    fun currentState(): ShizukuState {
        if (!isShizukuBinderAlive()) {
            return if (isShizukuAppInstalled()) ShizukuState.NOT_RUNNING else ShizukuState.NOT_INSTALLED
        }
        return if (hasPermission()) ShizukuState.AUTHORIZED else ShizukuState.RUNNING_NOT_AUTHORIZED
    }

    private fun isShizukuBinderAlive(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    private fun isShizukuAppInstalled(): Boolean = try {
        context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun shouldShowPermissionRationale(): Boolean = try {
        Shizuku.shouldShowRequestPermissionRationale()
    } catch (e: Throwable) {
        false
    }

    /**
     * Requests Shizuku permission. Result arrives async via the listener registered
     * in registerPermissionListener — Shizuku shows its own system-level consent UI,
     * this call does not grant anything silently.
     */
    fun requestPermission(requestCode: Int) {
        if (isShizukuBinderAlive()) {
            Shizuku.requestPermission(requestCode)
        }
    }

    fun registerPermissionListener(onResult: (granted: Boolean) -> Unit) {
        permissionListener?.let { Shizuku.removeRequestPermissionResultListener(it) }
        val listener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
            onResult(grantResult == PackageManager.PERMISSION_GRANTED)
        }
        permissionListener = listener
        Shizuku.addRequestPermissionResultListener(listener)
    }

    fun unregisterPermissionListener() {
        permissionListener?.let { Shizuku.removeRequestPermissionResultListener(it) }
        permissionListener = null
    }
}
