package com.redcore.performance.domain.manager

/**
 * Snapshot of real device metrics, all sourced from official Android APIs.
 * Fields that Android does not expose to third-party apps (raw GPU usage/frequency,
 * per-core CPU frequency without root, touch sampling rate) are intentionally omitted
 * rather than faked. Where a value depends on root, it is nullable and only populated
 * when RootManager confirms access.
 */
data class DeviceStats(
    val ramTotalBytes: Long,
    val ramAvailableBytes: Long,
    val ramUsedBytes: Long,
    val isLowRamDevice: Boolean,

    val storageTotalBytes: Long,
    val storageFreeBytes: Long,

    val batteryPercent: Int,
    val batteryTemperatureCelsius: Float,
    val isCharging: Boolean,
    val chargePlugType: String,
    val batteryHealth: String,

    val cpuCoreCount: Int,
    val cpuAbi: String,

    val networkType: String,
    val isNetworkConnected: Boolean,

    val displayRefreshRateHz: Float,

    val timestampMs: Long
) {
    val ramUsedPercent: Int
        get() = if (ramTotalBytes > 0) ((ramUsedBytes * 100) / ramTotalBytes).toInt() else 0

    val storageUsedPercent: Int
        get() = if (storageTotalBytes > 0) (((storageTotalBytes - storageFreeBytes) * 100) / storageTotalBytes).toInt() else 0
}
