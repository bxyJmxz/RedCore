package com.redcore.performance.ui.touch

import android.os.Bundle
import android.view.Display
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.fragment.app.Fragment
import com.redcore.performance.databinding.FragmentTouchResponseBinding

class TouchResponseFragment : Fragment() {

    private var _binding: FragmentTouchResponseBinding? = null
    private val binding get() = _binding!!

    private var maxPointersSeen = 1
    private var lastLatencies = mutableListOf<Long>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTouchResponseBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val refreshRate = getDisplayRefreshRate()
        binding.refreshRateValue.text = "${"%.1f".format(refreshRate)} Hz"

        binding.touchSurface.onTouchSample = { latencyMs, pointerCount ->
            lastLatencies.add(latencyMs)
            if (lastLatencies.size > 30) lastLatencies.removeAt(0)
            if (pointerCount > maxPointersSeen) maxPointersSeen = pointerCount

            val avg = lastLatencies.average()
            binding.latencyValue.text = "${latencyMs} ms"
            binding.avgLatencyValue.text = "avg ${"%.1f".format(avg)} ms over ${lastLatencies.size} samples"
            binding.pointerCountValue.text = pointerCount.toString()
            binding.maxPointerValue.text = "max seen this session: $maxPointersSeen"
        }

        binding.resetButton.setOnClickListener {
            lastLatencies.clear()
            maxPointersSeen = 1
            binding.latencyValue.text = "—"
            binding.avgLatencyValue.text = "Touch the panel below to start"
            binding.pointerCountValue.text = "0"
            binding.maxPointerValue.text = "max seen this session: 1"
        }
    }

    private fun getDisplayRefreshRate(): Float = try {
        val display: Display? = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            requireContext().display
        } else {
            @Suppress("DEPRECATION")
            (requireContext().getSystemService(android.content.Context.WINDOW_SERVICE) as WindowManager).defaultDisplay
        }
        display?.refreshRate ?: 60f
    } catch (e: Exception) {
        60f
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
