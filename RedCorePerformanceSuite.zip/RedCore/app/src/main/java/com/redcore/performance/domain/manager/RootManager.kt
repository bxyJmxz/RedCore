package com.redcore.performance.domain.manager

import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

sealed class RootAccessState {
    object NotRequested : RootAccessState()
    object Denied : RootAccessState()
    object Granted : RootAccessState()
}

/**
 * Detects whether the device is rooted and, only after the user explicitly taps
 * "Request Root Access" in Settings, asks the su binary for permission via the
 * standard Android su prompt (the same mechanism Magisk/SuperSU expose to any app).
 *
 * This class does not attempt to bypass Android security, exploit anything, or
 * grant itself access silently. If su isn't present or the user denies the prompt,
 * every root-gated feature in the app must stay disabled — callers should check
 * accessState before showing root-only UI.
 */
@Singleton
class RootManager @Inject constructor() {

    var accessState: RootAccessState = RootAccessState.NotRequested
        private set

    /** Detects common su binary locations. Presence alone does not grant access. */
    fun isDeviceRooted(): Boolean {
        val paths = listOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su",
            "/su/bin/su"
        )
        return paths.any { File(it).exists() }
    }

    /**
     * Requests a root shell. This triggers the OS-level su permission dialog
     * (Magisk/SuperSU) the same way any rooted app would. Must only be called
     * in direct response to explicit user action (a button tap), never automatically.
     */
    fun requestRootAccess(): RootAccessState {
        if (!isDeviceRooted()) {
            accessState = RootAccessState.Denied
            return accessState
        }
        accessState = try {
            val process = Runtime.getRuntime().exec("su")
            process.outputStream.write("id\n".toByteArray())
            process.outputStream.flush()
            process.outputStream.close()
            val exitCode = process.waitFor()
            if (exitCode == 0) RootAccessState.Granted else RootAccessState.Denied
        } catch (e: Exception) {
            RootAccessState.Denied
        }
        return accessState
    }

    fun revokeSession() {
        accessState = RootAccessState.NotRequested
    }
}
