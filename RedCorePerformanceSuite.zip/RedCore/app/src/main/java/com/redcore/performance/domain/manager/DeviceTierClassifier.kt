package com.redcore.performance.domain.manager

import android.app.ActivityManager
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

enum class DeviceTier { LOW_END, MID_RANGE, FLAGSHIP }

/**
 * Classifies the device once at startup so the UI layer can scale animation
 * quality, blur, and refresh intervals accordingly. Uses only RAM size, core
 * count, and ActivityManager.isLowRamDevice — all real, queryable signals.
 * This is a heuristic, not a benchmark score.
 */
@Singleton
class DeviceTierClassifier @Inject constructor(
    @ApplicationContext private val context: Context
) {
    val tier: DeviceTier by lazy { classify() }

    private fun classify(): DeviceTier {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val totalRamGb = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)
        val cores = Runtime.getRuntime().availableProcessors()

        return when {
            am.isLowRamDevice || totalRamGb < 4 || cores <= 4 -> DeviceTier.LOW_END
            totalRamGb < 8 || cores <= 6 -> DeviceTier.MID_RANGE
            else -> DeviceTier.FLAGSHIP
        }
    }

    /** Suggested polling interval in ms, scaled to tier. */
    fun suggestedRefreshIntervalMs(): Long = when (tier) {
        DeviceTier.LOW_END -> 3000L
        DeviceTier.MID_RANGE -> 2000L
        DeviceTier.FLAGSHIP -> 1000L
    }

    /** Whether to enable glass-blur / heavy MotionLayout effects. */
    fun allowPremiumEffects(): Boolean = tier == DeviceTier.FLAGSHIP
}
