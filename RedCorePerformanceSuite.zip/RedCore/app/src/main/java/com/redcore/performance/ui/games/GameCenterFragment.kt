package com.redcore.performance.ui.games

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.redcore.performance.databinding.FragmentGameCenterBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class GameCenterFragment : Fragment() {

    private var _binding: FragmentGameCenterBinding? = null
    private val binding get() = _binding!!
    private val viewModel: GameCenterViewModel by viewModels()

    private val profiles = arrayOf("Battery Saver", "Balanced", "Performance", "Competitive")

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentGameCenterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = GameCenterAdapter(
            onLaunch = { item ->
                val launchIntent = requireContext().packageManager
                    .getLaunchIntentForPackage(item.game.packageName)
                if (launchIntent != null) {
                    startActivity(launchIntent)
                } else {
                    Toast.makeText(requireContext(), "Unable to launch ${item.game.appName}", Toast.LENGTH_SHORT).show()
                }
            },
            onFavoriteToggle = { item ->
                viewModel.toggleFavorite(item.game.packageName, item.isFavorite)
            },
            onProfileClick = { item ->
                showProfilePicker(item)
            }
        )
        binding.gamesList.layoutManager = LinearLayoutManager(requireContext())
        binding.gamesList.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener {
            viewModel.scanForGames()
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.gameList.collect { list ->
                        adapter.submitList(list)
                        binding.emptyState.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                    }
                }
                launch {
                    viewModel.isLoading.collect { loading ->
                        binding.swipeRefresh.isRefreshing = loading
                    }
                }
                launch {
                    viewModel.namedGames.collect { named ->
                        renderNamedGameChips(named)
                    }
                }
            }
        }
        viewModel.scanForGames()
    }

    private fun renderNamedGameChips(named: List<com.redcore.performance.domain.manager.NamedGameStatus>) {
        binding.namedGamesChipGroup.removeAllViews()
        named.forEach { status ->
            val chip = Chip(requireContext())
            chip.text = status.displayName
            chip.isCheckable = status.isInstalled
            chip.isEnabled = status.isInstalled
            chip.isChecked = false
            if (!status.isInstalled) {
                chip.text = "${status.displayName} (not installed)"
            }
            chip.setOnCheckedChangeListener { _, checked ->
                if (!status.isInstalled) return@setOnCheckedChangeListener
                viewModel.setProfile(status.packageName, if (checked) "Performance" else "Balanced")
                Toast.makeText(
                    requireContext(),
                    if (checked) "${status.displayName} set to Performance profile"
                    else "${status.displayName} reset to Balanced",
                    Toast.LENGTH_SHORT
                ).show()
            }
            binding.namedGamesChipGroup.addView(chip)
        }
    }

    private fun showProfilePicker(item: GameListItem) {
        val currentIndex = profiles.indexOf(item.profile).coerceAtLeast(0)
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Profile for ${item.game.appName}")
            .setSingleChoiceItems(profiles, currentIndex) { dialog, which ->
                viewModel.setProfile(item.game.packageName, profiles[which])
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
