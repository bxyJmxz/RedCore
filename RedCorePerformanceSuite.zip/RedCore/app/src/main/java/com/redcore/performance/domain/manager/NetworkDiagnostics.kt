package com.redcore.performance.domain.manager

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import javax.inject.Inject
import javax.inject.Singleton

data class PingResult(val host: String, val reachable: Boolean, val latencyMs: Long)

/**
 * Real network diagnostics using actual TCP socket connection timing —
 * not a simulated number. Pings common, reliable public hosts on port 443/53.
 */
@Singleton
class NetworkDiagnostics @Inject constructor() {

    suspend fun pingHost(host: String, port: Int = 443, timeoutMs: Int = 2000): PingResult =
        withContext(Dispatchers.IO) {
            val start = System.currentTimeMillis()
            val reachable = try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(host, port), timeoutMs)
                    true
                }
            } catch (e: Exception) {
                false
            }
            val elapsed = System.currentTimeMillis() - start
            PingResult(host, reachable, elapsed)
        }

    suspend fun runDiagnostics(): List<PingResult> = withContext(Dispatchers.IO) {
        listOf(
            pingHost("1.1.1.1"),
            pingHost("8.8.8.8"),
            pingHost("google.com")
        )
    }
}
