package com.redcore.performance.ui.appmanager

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class AppManagerViewModel @Inject constructor(
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _apps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val apps: StateFlow<List<InstalledAppInfo>> = _apps.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private var showSystemApps = false
    private var masterList: List<InstalledAppInfo> = emptyList()

    fun loadApps() {
        viewModelScope.launch {
            _isLoading.value = true
            val list = withContext(Dispatchers.Default) {
                val pm = context.packageManager
                pm.getInstalledApplications(PackageManager.GET_META_DATA)
                    .filter { showSystemApps || (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
                    .map { appInfo ->
                        val pkgInfo = try { pm.getPackageInfo(appInfo.packageName, 0) } catch (e: Exception) { null }
                        InstalledAppInfo(
                            appName = pm.getApplicationLabel(appInfo).toString(),
                            packageName = appInfo.packageName,
                            versionName = pkgInfo?.versionName,
                            isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                            icon = try { pm.getApplicationIcon(appInfo) } catch (e: Exception) { null }
                        )
                    }
                    .sortedBy { it.appName.lowercase() }
            }
            masterList = list
            _apps.value = list
            _isLoading.value = false
        }
    }

    fun toggleSystemApps() {
        showSystemApps = !showSystemApps
        loadApps()
    }

    fun search(query: String) {
        _apps.value = if (query.isBlank()) masterList
        else masterList.filter { it.appName.contains(query, ignoreCase = true) }
    }
}
