package com.redcore.performance.ui.logs

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.redcore.performance.data.entities.LogEntry
import com.redcore.performance.databinding.ItemLogEntryBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LogsAdapter : ListAdapter<LogEntry, LogsAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemLogEntryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    class ViewHolder(private val binding: ItemLogEntryBinding) : RecyclerView.ViewHolder(binding.root) {
        private val dateFormat = SimpleDateFormat("MMM d, HH:mm:ss", Locale.getDefault())
        fun bind(entry: LogEntry) {
            binding.categoryText.text = entry.category
            binding.messageText.text = entry.message
            binding.timeText.text = dateFormat.format(Date(entry.timestampMs))
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<LogEntry>() {
            override fun areItemsTheSame(old: LogEntry, new: LogEntry) = old.id == new.id
            override fun areContentsTheSame(old: LogEntry, new: LogEntry) = old == new
        }
    }
}
