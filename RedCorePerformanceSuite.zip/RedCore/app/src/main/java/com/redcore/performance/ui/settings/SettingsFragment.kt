package com.redcore.performance.ui.settings

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import com.redcore.performance.domain.manager.TweakResult
import com.redcore.performance.domain.manager.TweaksManager
import com.redcore.performance.domain.shizuku.ShizukuManager
import com.redcore.performance.domain.shizuku.ShizukuState
import com.redcore.performance.databinding.FragmentSettingsBinding
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    @Inject lateinit var tweaksManager: TweaksManager
    @Inject lateinit var shizukuManager: ShizukuManager

    companion object {
        private const val SHIZUKU_PERMISSION_REQUEST_CODE = 5001
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val prefs = requireContext().getSharedPreferences("redcore_settings", Context.MODE_PRIVATE)

        binding.darkThemeSwitch.isChecked = prefs.getBoolean("force_dark", true)
        binding.darkThemeSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("force_dark", checked).apply()
            AppCompatDelegate.setDefaultNightMode(
                if (checked) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            )
        }

        binding.rootConfirmationSwitch.isChecked = prefs.getBoolean("require_root_confirmation", true)
        binding.rootConfirmationSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("require_root_confirmation", checked).apply()
        }

        setupShizukuSection()
        setupTweaksSection()
        setupUniversalModeSection()
    }

    // ---------- Shizuku ----------

    private fun setupShizukuSection() {
        refreshShizukuStatus()
        shizukuManager.registerPermissionListener { granted ->
            Toast.makeText(
                requireContext(),
                if (granted) "Shizuku authorized" else "Shizuku permission denied",
                Toast.LENGTH_SHORT
            ).show()
            refreshShizukuStatus()
        }
        binding.shizukuActionButton.setOnClickListener {
            when (shizukuManager.currentState()) {
                ShizukuState.NOT_INSTALLED -> {
                    Toast.makeText(requireContext(), "Install Shizuku from the Play Store or GitHub first", Toast.LENGTH_LONG).show()
                }
                ShizukuState.NOT_RUNNING -> {
                    Toast.makeText(requireContext(), "Start Shizuku via its app (root or wireless ADB pairing)", Toast.LENGTH_LONG).show()
                }
                ShizukuState.RUNNING_NOT_AUTHORIZED -> {
                    shizukuManager.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
                }
                ShizukuState.AUTHORIZED -> {
                    Toast.makeText(requireContext(), "Shizuku already authorized", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun refreshShizukuStatus() {
        val state = shizukuManager.currentState()
        binding.shizukuStatusText.text = when (state) {
            ShizukuState.NOT_INSTALLED -> "Not installed"
            ShizukuState.NOT_RUNNING -> "Installed, not running"
            ShizukuState.RUNNING_NOT_AUTHORIZED -> "Running \u2014 authorization needed"
            ShizukuState.AUTHORIZED -> "Authorized"
        }
        binding.shizukuActionButton.text = when (state) {
            ShizukuState.NOT_INSTALLED -> "How to install"
            ShizukuState.NOT_RUNNING -> "How to start Shizuku"
            ShizukuState.RUNNING_NOT_AUTHORIZED -> "Request Permission"
            ShizukuState.AUTHORIZED -> "Authorized \u2713"
        }
    }

    // ---------- Tweaks ----------

    private fun setupTweaksSection() {
        binding.dndSwitch.isChecked = tweaksManager.isDoNotDisturbActive()
        binding.dndSwitch.setOnCheckedChangeListener { switchView, checked ->
            when (val result = tweaksManager.setDoNotDisturb(checked)) {
                is TweakResult.Success -> { /* UI already reflects requested state */ }
                is TweakResult.PermissionRequired -> {
                    switchView.isChecked = !checked
                    Toast.makeText(requireContext(), "Grant notification access to control Do Not Disturb", Toast.LENGTH_LONG).show()
                    startActivity(tweaksManager.notificationPolicyAccessIntent())
                }
                is TweakResult.Failed -> {
                    switchView.isChecked = !checked
                    Toast.makeText(requireContext(), "Failed: ${result.reason}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        binding.batteryExemptionButton.setOnClickListener {
            if (tweaksManager.isIgnoringBatteryOptimizations()) {
                Toast.makeText(requireContext(), "Already exempted from battery optimization", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(tweaksManager.requestIgnoreBatteryOptimizationsIntent())
            }
        }

        val prefs = requireContext().getSharedPreferences("redcore_settings", Context.MODE_PRIVATE)

        binding.brightnessLockSwitch.setOnCheckedChangeListener { switchView, checked ->
            if (checked) {
                when (val result = tweaksManager.lockBrightness(80)) {
                    is TweakResult.Success -> { /* locked */ }
                    is TweakResult.PermissionRequired -> {
                        switchView.isChecked = false
                        Toast.makeText(requireContext(), "Grant \"Modify system settings\" to lock brightness", Toast.LENGTH_LONG).show()
                        startActivity(tweaksManager.writeSettingsPermissionIntent())
                    }
                    is TweakResult.Failed -> {
                        switchView.isChecked = false
                        Toast.makeText(requireContext(), "Failed: ${result.reason}", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                tweaksManager.restoreAutoBrightness()
            }
        }

        binding.screenTimeoutSwitch.setOnCheckedChangeListener { switchView, checked ->
            if (checked) {
                val originalTimeout = tweaksManager.currentScreenTimeoutMs()
                when (val result = tweaksManager.setScreenTimeout(10 * 60 * 1000)) {
                    is TweakResult.Success -> {
                        prefs.edit().putInt("saved_screen_timeout_ms", originalTimeout).apply()
                    }
                    is TweakResult.PermissionRequired -> {
                        switchView.isChecked = false
                        Toast.makeText(requireContext(), "Grant \"Modify system settings\" to change screen timeout", Toast.LENGTH_LONG).show()
                        startActivity(tweaksManager.writeSettingsPermissionIntent())
                    }
                    is TweakResult.Failed -> {
                        switchView.isChecked = false
                        Toast.makeText(requireContext(), "Failed: ${result.reason}", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                val original = prefs.getInt("saved_screen_timeout_ms", 30000)
                tweaksManager.setScreenTimeout(original)
            }
        }

        binding.devOptionsButton.setOnClickListener {
            startActivity(tweaksManager.developerOptionsIntent())
        }

        binding.clearCacheButton.setOnClickListener {
            val freedBytes = tweaksManager.clearAppCache()
            val freedKb = freedBytes / 1024
            Toast.makeText(requireContext(), "Cleared ${freedKb} KB of cache", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Universal Performance Mode ----------

    private fun setupUniversalModeSection() {
        binding.universalModeSwitch.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                applyUniversalMode()
            } else {
                revertUniversalMode()
            }
        }
    }

    private fun applyUniversalMode() {
        val applied = mutableListOf<String>()
        val skipped = mutableListOf<String>()

        when (tweaksManager.setDoNotDisturb(true)) {
            is TweakResult.Success -> applied.add("DND")
            else -> skipped.add("DND (grant notification access)")
        }
        when (tweaksManager.lockBrightness(80)) {
            is TweakResult.Success -> applied.add("Brightness lock")
            else -> skipped.add("Brightness lock (grant modify settings)")
        }
        when (tweaksManager.setScreenTimeout(10 * 60 * 1000)) {
            is TweakResult.Success -> applied.add("Screen timeout")
            else -> skipped.add("Screen timeout (grant modify settings)")
        }
        if (!tweaksManager.isIgnoringBatteryOptimizations()) {
            skipped.add("Battery exemption (tap the button above)")
        } else {
            applied.add("Battery exemption")
        }

        binding.dndSwitch.isChecked = tweaksManager.isDoNotDisturbActive()
        binding.brightnessLockSwitch.isChecked = applied.contains("Brightness lock")
        binding.screenTimeoutSwitch.isChecked = applied.contains("Screen timeout")

        binding.universalModeStatus.text = buildString {
            if (applied.isNotEmpty()) append("Applied: ${applied.joinToString()}. ")
            if (skipped.isNotEmpty()) append("Skipped: ${skipped.joinToString()}.")
        }
    }

    private fun revertUniversalMode() {
        tweaksManager.setDoNotDisturb(false)
        tweaksManager.restoreAutoBrightness()
        val prefs = requireContext().getSharedPreferences("redcore_settings", Context.MODE_PRIVATE)
        tweaksManager.setScreenTimeout(prefs.getInt("saved_screen_timeout_ms", 30000))

        binding.dndSwitch.isChecked = false
        binding.brightnessLockSwitch.isChecked = false
        binding.screenTimeoutSwitch.isChecked = false
        binding.universalModeStatus.text = "Reverted to your original settings."
    }

    override fun onDestroyView() {
        super.onDestroyView()
        shizukuManager.unregisterPermissionListener()
        _binding = null
    }
}
